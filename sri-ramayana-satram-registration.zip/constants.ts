// Supabase Configuration
// TODO: Replace with your actual project details from Supabase Dashboard -> Project Settings -> API
export const SUPABASE_URL = "https://zzotgfcpmiqplotrlyti.supabase.co"; 
export const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp6b3RnZmNwbWlxcGxvdHJseXRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA1NTM2NjUsImV4cCI6MjA4NjEyOTY2NX0.XSugjNNoTUFe6DjZsZhAhdN6k4J9rWUbuyFBp46NQX8";

export const EVENT_DATES = [
  "March 28, 2026",
  "March 29, 2026",
  "March 30, 2026",
  "March 31, 2026",
  "April 01, 2026",
  "April 02, 2026",
  "April 03, 2026",
  "April 04, 2026 (Conference Day1)",
  "April 05, 2026 (Conference Day2)",
  "April 06, 2026",
  "April 07, 2026",
];

export const CONTACT_PHONE = "9369637283";
export const CONTACT_EMAIL = "webolimclasses@gmail.com";
